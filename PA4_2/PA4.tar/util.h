

int hello();
int count_lines();
int getfilesize(char* filename);